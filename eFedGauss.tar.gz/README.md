# eGAUSSp_Python
 


conda install pytorch torchvision torchaudio pytorch-cuda=11.8 -c pytorch -c nvidia

